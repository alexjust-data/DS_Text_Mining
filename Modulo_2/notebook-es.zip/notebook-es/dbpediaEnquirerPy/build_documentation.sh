#!/bin/bash

epydoc -v --config documentation.cfg --no-private #--no-sourcecode
