OWL_FILE = "dbpedia_2014.owl.bz2"[:-4]
