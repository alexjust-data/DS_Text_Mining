from .query_dbpedia import Cdbpedia_enquirer, Cdbpedia_ontology

